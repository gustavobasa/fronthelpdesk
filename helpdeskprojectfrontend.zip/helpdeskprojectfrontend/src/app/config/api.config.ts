export const API_CONFIG = {
  baseUrl: 'http://localhost:8080' // Substitua pela URL do seu backend real
};
