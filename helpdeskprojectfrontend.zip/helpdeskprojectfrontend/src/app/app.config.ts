import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';

import { JwtModule } from '@auth0/angular-jwt';

export function tokenGetter() {
  return localStorage.getItem('token'); 
}

export const appConfig: ApplicationConfig = {
  providers: [
    // Registra o sistema de rotas
    provideRouter(routes),

    // Configuração do JWT
    importProvidersFrom(
      JwtModule.forRoot({
        config: {
          tokenGetter: tokenGetter,
          allowedDomains: ['localhost:8080'],   // Porta da sua API
          disallowedRoutes: ['http://localhost:8080/login'] // Endpoint que NÃO recebe token
        }
      })
    )
  ]
};
