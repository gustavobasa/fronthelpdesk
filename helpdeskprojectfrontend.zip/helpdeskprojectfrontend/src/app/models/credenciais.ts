export interface Credenciais {
    email: string;
    senha: string;
}